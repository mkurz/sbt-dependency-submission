/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
import _root_.sjsonnew.{ Unbuilder, Builder, JsonFormat, deserializationError }
trait SnapshotResponseFormats { self: sjsonnew.BasicJsonProtocol =>
implicit lazy val SnapshotResponseFormat: JsonFormat[ch.epfl.scala.githubapi.SnapshotResponse] = new JsonFormat[ch.epfl.scala.githubapi.SnapshotResponse] {
  override def read[J](__jsOpt: Option[J], unbuilder: Unbuilder[J]): ch.epfl.scala.githubapi.SnapshotResponse = {
    __jsOpt match {
      case Some(__js) =>
      unbuilder.beginObject(__js)
      val id = unbuilder.readField[Int]("id")
      val created_at = unbuilder.readField[Option[String]]("created_at")
      unbuilder.endObject()
      ch.epfl.scala.githubapi.SnapshotResponse(id, created_at)
      case None =>
      deserializationError("Expected JsObject but found None")
    }
  }
  override def write[J](obj: ch.epfl.scala.githubapi.SnapshotResponse, builder: Builder[J]): Unit = {
    builder.beginObject()
    builder.addField("id", obj.id)
    builder.addField("created_at", obj.created_at)
    builder.endObject()
  }
}
}
