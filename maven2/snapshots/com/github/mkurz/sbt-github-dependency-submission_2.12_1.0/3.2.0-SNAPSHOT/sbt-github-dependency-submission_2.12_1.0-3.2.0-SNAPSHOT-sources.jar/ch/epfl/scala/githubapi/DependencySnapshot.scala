/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
/**
 * Github Dependency Submission API version 0
 * Taken from https://gist.github.com/reiddraper/fdab2883db0f372c146d1a750fc1c43f
 * @param ref sha of the Git commit
 * @param detector ref of the Git commit; example: "refs/heads/main"
 */
final class DependencySnapshot private (
  val version: Int,
  val job: ch.epfl.scala.githubapi.Job,
  val sha: String,
  val ref: String,
  val detector: ch.epfl.scala.githubapi.DetectorMetadata,
  val metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue],
  val manifests: Map[String, ch.epfl.scala.githubapi.Manifest],
  val scanned: Option[String]) extends Serializable {
  
  
  
  override def equals(o: Any): Boolean = this.eq(o.asInstanceOf[AnyRef]) || (o match {
    case x: DependencySnapshot => (this.version == x.version) && (this.job == x.job) && (this.sha == x.sha) && (this.ref == x.ref) && (this.detector == x.detector) && (this.metadata == x.metadata) && (this.manifests == x.manifests) && (this.scanned == x.scanned)
    case _ => false
  })
  override def hashCode: Int = {
    37 * (37 * (37 * (37 * (37 * (37 * (37 * (37 * (37 * (17 + "ch.epfl.scala.githubapi.DependencySnapshot".##) + version.##) + job.##) + sha.##) + ref.##) + detector.##) + metadata.##) + manifests.##) + scanned.##)
  }
  override def toString: String = {
    "DependencySnapshot(" + version + ", " + job + ", " + sha + ", " + ref + ", " + detector + ", " + metadata + ", " + manifests + ", " + scanned + ")"
  }
  private def copy(version: Int = version, job: ch.epfl.scala.githubapi.Job = job, sha: String = sha, ref: String = ref, detector: ch.epfl.scala.githubapi.DetectorMetadata = detector, metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue] = metadata, manifests: Map[String, ch.epfl.scala.githubapi.Manifest] = manifests, scanned: Option[String] = scanned): DependencySnapshot = {
    new DependencySnapshot(version, job, sha, ref, detector, metadata, manifests, scanned)
  }
  def withVersion(version: Int): DependencySnapshot = {
    copy(version = version)
  }
  def withJob(job: ch.epfl.scala.githubapi.Job): DependencySnapshot = {
    copy(job = job)
  }
  def withSha(sha: String): DependencySnapshot = {
    copy(sha = sha)
  }
  def withRef(ref: String): DependencySnapshot = {
    copy(ref = ref)
  }
  def withDetector(detector: ch.epfl.scala.githubapi.DetectorMetadata): DependencySnapshot = {
    copy(detector = detector)
  }
  def withMetadata(metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue]): DependencySnapshot = {
    copy(metadata = metadata)
  }
  def withManifests(manifests: Map[String, ch.epfl.scala.githubapi.Manifest]): DependencySnapshot = {
    copy(manifests = manifests)
  }
  def withScanned(scanned: Option[String]): DependencySnapshot = {
    copy(scanned = scanned)
  }
  def withScanned(scanned: String): DependencySnapshot = {
    copy(scanned = Option(scanned))
  }
}
object DependencySnapshot {
  
  def apply(version: Int, job: ch.epfl.scala.githubapi.Job, sha: String, ref: String, detector: ch.epfl.scala.githubapi.DetectorMetadata, metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue], manifests: Map[String, ch.epfl.scala.githubapi.Manifest], scanned: Option[String]): DependencySnapshot = new DependencySnapshot(version, job, sha, ref, detector, metadata, manifests, scanned)
  def apply(version: Int, job: ch.epfl.scala.githubapi.Job, sha: String, ref: String, detector: ch.epfl.scala.githubapi.DetectorMetadata, metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue], manifests: Map[String, ch.epfl.scala.githubapi.Manifest], scanned: String): DependencySnapshot = new DependencySnapshot(version, job, sha, ref, detector, metadata, manifests, Option(scanned))
}
