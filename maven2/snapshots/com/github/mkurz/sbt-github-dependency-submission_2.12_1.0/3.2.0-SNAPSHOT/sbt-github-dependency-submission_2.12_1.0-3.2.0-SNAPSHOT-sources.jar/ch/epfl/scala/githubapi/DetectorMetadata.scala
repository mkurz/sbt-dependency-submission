/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
final class DetectorMetadata private (
  val name: String,
  val url: String,
  val version: String) extends Serializable {
  
  
  
  override def equals(o: Any): Boolean = this.eq(o.asInstanceOf[AnyRef]) || (o match {
    case x: DetectorMetadata => (this.name == x.name) && (this.url == x.url) && (this.version == x.version)
    case _ => false
  })
  override def hashCode: Int = {
    37 * (37 * (37 * (37 * (17 + "ch.epfl.scala.githubapi.DetectorMetadata".##) + name.##) + url.##) + version.##)
  }
  override def toString: String = {
    "DetectorMetadata(" + name + ", " + url + ", " + version + ")"
  }
  private def copy(name: String = name, url: String = url, version: String = version): DetectorMetadata = {
    new DetectorMetadata(name, url, version)
  }
  def withName(name: String): DetectorMetadata = {
    copy(name = name)
  }
  def withUrl(url: String): DetectorMetadata = {
    copy(url = url)
  }
  def withVersion(version: String): DetectorMetadata = {
    copy(version = version)
  }
}
object DetectorMetadata {
  
  def apply(name: String, url: String, version: String): DetectorMetadata = new DetectorMetadata(name, url, version)
}
