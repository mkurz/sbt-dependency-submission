/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
final class DependencyNode private (
  val package_url: String,
  val metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue],
  val relationship: Option[ch.epfl.scala.githubapi.DependencyRelationship],
  val scope: Option[ch.epfl.scala.githubapi.DependencyScope],
  val dependencies: Vector[String]) extends Serializable {
  
  
  
  override def equals(o: Any): Boolean = this.eq(o.asInstanceOf[AnyRef]) || (o match {
    case x: DependencyNode => (this.package_url == x.package_url) && (this.metadata == x.metadata) && (this.relationship == x.relationship) && (this.scope == x.scope) && (this.dependencies == x.dependencies)
    case _ => false
  })
  override def hashCode: Int = {
    37 * (37 * (37 * (37 * (37 * (37 * (17 + "ch.epfl.scala.githubapi.DependencyNode".##) + package_url.##) + metadata.##) + relationship.##) + scope.##) + dependencies.##)
  }
  override def toString: String = {
    "DependencyNode(" + package_url + ", " + metadata + ", " + relationship + ", " + scope + ", " + dependencies + ")"
  }
  private def copy(package_url: String = package_url, metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue] = metadata, relationship: Option[ch.epfl.scala.githubapi.DependencyRelationship] = relationship, scope: Option[ch.epfl.scala.githubapi.DependencyScope] = scope, dependencies: Vector[String] = dependencies): DependencyNode = {
    new DependencyNode(package_url, metadata, relationship, scope, dependencies)
  }
  def withPackage_url(package_url: String): DependencyNode = {
    copy(package_url = package_url)
  }
  def withMetadata(metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue]): DependencyNode = {
    copy(metadata = metadata)
  }
  def withRelationship(relationship: Option[ch.epfl.scala.githubapi.DependencyRelationship]): DependencyNode = {
    copy(relationship = relationship)
  }
  def withRelationship(relationship: ch.epfl.scala.githubapi.DependencyRelationship): DependencyNode = {
    copy(relationship = Option(relationship))
  }
  def withScope(scope: Option[ch.epfl.scala.githubapi.DependencyScope]): DependencyNode = {
    copy(scope = scope)
  }
  def withScope(scope: ch.epfl.scala.githubapi.DependencyScope): DependencyNode = {
    copy(scope = Option(scope))
  }
  def withDependencies(dependencies: Vector[String]): DependencyNode = {
    copy(dependencies = dependencies)
  }
}
object DependencyNode {
  
  def apply(package_url: String, metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue], relationship: Option[ch.epfl.scala.githubapi.DependencyRelationship], scope: Option[ch.epfl.scala.githubapi.DependencyScope], dependencies: Vector[String]): DependencyNode = new DependencyNode(package_url, metadata, relationship, scope, dependencies)
  def apply(package_url: String, metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue], relationship: ch.epfl.scala.githubapi.DependencyRelationship, scope: ch.epfl.scala.githubapi.DependencyScope, dependencies: Vector[String]): DependencyNode = new DependencyNode(package_url, metadata, Option(relationship), Option(scope), dependencies)
}
