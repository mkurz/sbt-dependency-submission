/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
import _root_.sjsonnew.{ Unbuilder, Builder, JsonFormat, deserializationError }
trait DependencyRelationshipFormats { self: sjsonnew.BasicJsonProtocol =>
implicit lazy val DependencyRelationshipFormat: JsonFormat[ch.epfl.scala.githubapi.DependencyRelationship] = new JsonFormat[ch.epfl.scala.githubapi.DependencyRelationship] {
  override def read[J](__jsOpt: Option[J], unbuilder: Unbuilder[J]): ch.epfl.scala.githubapi.DependencyRelationship = {
    __jsOpt match {
      case Some(__js) =>
      unbuilder.readString(__js) match {
        case "direct" => ch.epfl.scala.githubapi.DependencyRelationship.direct
        case "indirect" => ch.epfl.scala.githubapi.DependencyRelationship.indirect
      }
      case None =>
      deserializationError("Expected JsString but found None")
    }
  }
  override def write[J](obj: ch.epfl.scala.githubapi.DependencyRelationship, builder: Builder[J]): Unit = {
    val str = obj match {
      case ch.epfl.scala.githubapi.DependencyRelationship.direct => "direct"
      case ch.epfl.scala.githubapi.DependencyRelationship.indirect => "indirect"
    }
    builder.writeString(str)
  }
}
}
