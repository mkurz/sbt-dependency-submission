/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala
trait JsonProtocol extends sjsonnew.BasicJsonProtocol
  with ch.epfl.scala.OnFailureFormats
  with ch.epfl.scala.DependencySnapshotInputFormats
object JsonProtocol extends JsonProtocol