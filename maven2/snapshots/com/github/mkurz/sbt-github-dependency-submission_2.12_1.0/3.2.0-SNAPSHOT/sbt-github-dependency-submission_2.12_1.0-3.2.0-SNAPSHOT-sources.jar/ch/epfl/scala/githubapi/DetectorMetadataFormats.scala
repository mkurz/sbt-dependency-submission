/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
import _root_.sjsonnew.{ Unbuilder, Builder, JsonFormat, deserializationError }
trait DetectorMetadataFormats { self: sjsonnew.BasicJsonProtocol =>
implicit lazy val DetectorMetadataFormat: JsonFormat[ch.epfl.scala.githubapi.DetectorMetadata] = new JsonFormat[ch.epfl.scala.githubapi.DetectorMetadata] {
  override def read[J](__jsOpt: Option[J], unbuilder: Unbuilder[J]): ch.epfl.scala.githubapi.DetectorMetadata = {
    __jsOpt match {
      case Some(__js) =>
      unbuilder.beginObject(__js)
      val name = unbuilder.readField[String]("name")
      val url = unbuilder.readField[String]("url")
      val version = unbuilder.readField[String]("version")
      unbuilder.endObject()
      ch.epfl.scala.githubapi.DetectorMetadata(name, url, version)
      case None =>
      deserializationError("Expected JsObject but found None")
    }
  }
  override def write[J](obj: ch.epfl.scala.githubapi.DetectorMetadata, builder: Builder[J]): Unit = {
    builder.beginObject()
    builder.addField("name", obj.name)
    builder.addField("url", obj.url)
    builder.addField("version", obj.version)
    builder.endObject()
  }
}
}
