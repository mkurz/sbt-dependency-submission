/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
import _root_.sjsonnew.{ Unbuilder, Builder, JsonFormat, deserializationError }
trait JobFormats { self: sjsonnew.BasicJsonProtocol =>
implicit lazy val JobFormat: JsonFormat[ch.epfl.scala.githubapi.Job] = new JsonFormat[ch.epfl.scala.githubapi.Job] {
  override def read[J](__jsOpt: Option[J], unbuilder: Unbuilder[J]): ch.epfl.scala.githubapi.Job = {
    __jsOpt match {
      case Some(__js) =>
      unbuilder.beginObject(__js)
      val correlator = unbuilder.readField[String]("correlator")
      val id = unbuilder.readField[String]("id")
      val html_url = unbuilder.readField[Option[String]]("html_url")
      unbuilder.endObject()
      ch.epfl.scala.githubapi.Job(correlator, id, html_url)
      case None =>
      deserializationError("Expected JsObject but found None")
    }
  }
  override def write[J](obj: ch.epfl.scala.githubapi.Job, builder: Builder[J]): Unit = {
    builder.beginObject()
    builder.addField("correlator", obj.correlator)
    builder.addField("id", obj.id)
    builder.addField("html_url", obj.html_url)
    builder.endObject()
  }
}
}
