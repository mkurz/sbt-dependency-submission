/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
import _root_.sjsonnew.{ Unbuilder, Builder, JsonFormat, deserializationError }
trait DependencySnapshotFormats { self: ch.epfl.scala.githubapi.JobFormats with sjsonnew.BasicJsonProtocol with ch.epfl.scala.githubapi.DetectorMetadataFormats with sbt.internal.util.codec.JValueFormats with ch.epfl.scala.githubapi.ManifestFormats =>
implicit lazy val DependencySnapshotFormat: JsonFormat[ch.epfl.scala.githubapi.DependencySnapshot] = new JsonFormat[ch.epfl.scala.githubapi.DependencySnapshot] {
  override def read[J](__jsOpt: Option[J], unbuilder: Unbuilder[J]): ch.epfl.scala.githubapi.DependencySnapshot = {
    __jsOpt match {
      case Some(__js) =>
      unbuilder.beginObject(__js)
      val version = unbuilder.readField[Int]("version")
      val job = unbuilder.readField[ch.epfl.scala.githubapi.Job]("job")
      val sha = unbuilder.readField[String]("sha")
      val ref = unbuilder.readField[String]("ref")
      val detector = unbuilder.readField[ch.epfl.scala.githubapi.DetectorMetadata]("detector")
      val metadata = unbuilder.readField[Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue]]("metadata")
      val manifests = unbuilder.readField[Map[String, ch.epfl.scala.githubapi.Manifest]]("manifests")
      val scanned = unbuilder.readField[Option[String]]("scanned")
      unbuilder.endObject()
      ch.epfl.scala.githubapi.DependencySnapshot(version, job, sha, ref, detector, metadata, manifests, scanned)
      case None =>
      deserializationError("Expected JsObject but found None")
    }
  }
  override def write[J](obj: ch.epfl.scala.githubapi.DependencySnapshot, builder: Builder[J]): Unit = {
    builder.beginObject()
    builder.addField("version", obj.version)
    builder.addField("job", obj.job)
    builder.addField("sha", obj.sha)
    builder.addField("ref", obj.ref)
    builder.addField("detector", obj.detector)
    builder.addField("metadata", obj.metadata)
    builder.addField("manifests", obj.manifests)
    builder.addField("scanned", obj.scanned)
    builder.endObject()
  }
}
}
