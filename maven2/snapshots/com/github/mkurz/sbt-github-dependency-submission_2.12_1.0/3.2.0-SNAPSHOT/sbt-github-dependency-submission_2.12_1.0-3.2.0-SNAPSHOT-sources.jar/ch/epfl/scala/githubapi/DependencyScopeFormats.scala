/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
import _root_.sjsonnew.{ Unbuilder, Builder, JsonFormat, deserializationError }
trait DependencyScopeFormats { self: sjsonnew.BasicJsonProtocol =>
implicit lazy val DependencyScopeFormat: JsonFormat[ch.epfl.scala.githubapi.DependencyScope] = new JsonFormat[ch.epfl.scala.githubapi.DependencyScope] {
  override def read[J](__jsOpt: Option[J], unbuilder: Unbuilder[J]): ch.epfl.scala.githubapi.DependencyScope = {
    __jsOpt match {
      case Some(__js) =>
      unbuilder.readString(__js) match {
        case "runtime" => ch.epfl.scala.githubapi.DependencyScope.runtime
        case "development" => ch.epfl.scala.githubapi.DependencyScope.development
      }
      case None =>
      deserializationError("Expected JsString but found None")
    }
  }
  override def write[J](obj: ch.epfl.scala.githubapi.DependencyScope, builder: Builder[J]): Unit = {
    val str = obj match {
      case ch.epfl.scala.githubapi.DependencyScope.runtime => "runtime"
      case ch.epfl.scala.githubapi.DependencyScope.development => "development"
    }
    builder.writeString(str)
  }
}
}
