/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
/**
 * A notation of whether a dependency is requested directly
 * by this manifest, or is a dependency of another dependency.
 */
sealed abstract class DependencyRelationship extends Serializable
object DependencyRelationship {
  
  
  case object direct extends DependencyRelationship
  case object indirect extends DependencyRelationship
}
