/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
final class Job private (
  val correlator: String,
  val id: String,
  val html_url: Option[String]) extends Serializable {
  
  
  
  override def equals(o: Any): Boolean = this.eq(o.asInstanceOf[AnyRef]) || (o match {
    case x: Job => (this.correlator == x.correlator) && (this.id == x.id) && (this.html_url == x.html_url)
    case _ => false
  })
  override def hashCode: Int = {
    37 * (37 * (37 * (37 * (17 + "ch.epfl.scala.githubapi.Job".##) + correlator.##) + id.##) + html_url.##)
  }
  override def toString: String = {
    "Job(" + correlator + ", " + id + ", " + html_url + ")"
  }
  private def copy(correlator: String = correlator, id: String = id, html_url: Option[String] = html_url): Job = {
    new Job(correlator, id, html_url)
  }
  def withCorrelator(correlator: String): Job = {
    copy(correlator = correlator)
  }
  def withId(id: String): Job = {
    copy(id = id)
  }
  def withHtml_url(html_url: Option[String]): Job = {
    copy(html_url = html_url)
  }
  def withHtml_url(html_url: String): Job = {
    copy(html_url = Option(html_url))
  }
}
object Job {
  
  def apply(correlator: String, id: String, html_url: Option[String]): Job = new Job(correlator, id, html_url)
  def apply(correlator: String, id: String, html_url: String): Job = new Job(correlator, id, Option(html_url))
}
