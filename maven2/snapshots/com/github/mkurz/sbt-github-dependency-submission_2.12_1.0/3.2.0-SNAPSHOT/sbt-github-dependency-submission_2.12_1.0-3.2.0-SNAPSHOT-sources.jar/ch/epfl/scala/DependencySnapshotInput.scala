/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala
/**
 * Input of the githubGenerateSnapshot command
 * @param ignoredModules A set of modules to ignore.
                         The name of module is composed of the name of the project and its binary version.
                         Example: foo_2.13
 * @param ignoredConfigs A set of sbt configurations to ignore.
                         Examples:
                         - "test" to ignore the test dependencies
                         - "scala-doc-tool" to ignore the scaladoc dependencies
                         - "scala-tool" to ignore the compiler dependencies
 * @param correlator The job correlator of the snapshot
 * @param manifestPrefix TODO
 * @param refOverride TODO
 */
final class DependencySnapshotInput private (
  val onResolveFailure: Option[ch.epfl.scala.OnFailure],
  val ignoredModules: Vector[String],
  val ignoredConfigs: Vector[String],
  val correlator: Option[String],
  val manifestPrefix: Option[String],
  val refOverride: Option[String]) extends Serializable {
  
  
  
  override def equals(o: Any): Boolean = this.eq(o.asInstanceOf[AnyRef]) || (o match {
    case x: DependencySnapshotInput => (this.onResolveFailure == x.onResolveFailure) && (this.ignoredModules == x.ignoredModules) && (this.ignoredConfigs == x.ignoredConfigs) && (this.correlator == x.correlator) && (this.manifestPrefix == x.manifestPrefix) && (this.refOverride == x.refOverride)
    case _ => false
  })
  override def hashCode: Int = {
    37 * (37 * (37 * (37 * (37 * (37 * (37 * (17 + "ch.epfl.scala.DependencySnapshotInput".##) + onResolveFailure.##) + ignoredModules.##) + ignoredConfigs.##) + correlator.##) + manifestPrefix.##) + refOverride.##)
  }
  override def toString: String = {
    "DependencySnapshotInput(" + onResolveFailure + ", " + ignoredModules + ", " + ignoredConfigs + ", " + correlator + ", " + manifestPrefix + ", " + refOverride + ")"
  }
  private def copy(onResolveFailure: Option[ch.epfl.scala.OnFailure] = onResolveFailure, ignoredModules: Vector[String] = ignoredModules, ignoredConfigs: Vector[String] = ignoredConfigs, correlator: Option[String] = correlator, manifestPrefix: Option[String] = manifestPrefix, refOverride: Option[String] = refOverride): DependencySnapshotInput = {
    new DependencySnapshotInput(onResolveFailure, ignoredModules, ignoredConfigs, correlator, manifestPrefix, refOverride)
  }
  def withOnResolveFailure(onResolveFailure: Option[ch.epfl.scala.OnFailure]): DependencySnapshotInput = {
    copy(onResolveFailure = onResolveFailure)
  }
  def withOnResolveFailure(onResolveFailure: ch.epfl.scala.OnFailure): DependencySnapshotInput = {
    copy(onResolveFailure = Option(onResolveFailure))
  }
  def withIgnoredModules(ignoredModules: Vector[String]): DependencySnapshotInput = {
    copy(ignoredModules = ignoredModules)
  }
  def withIgnoredConfigs(ignoredConfigs: Vector[String]): DependencySnapshotInput = {
    copy(ignoredConfigs = ignoredConfigs)
  }
  def withCorrelator(correlator: Option[String]): DependencySnapshotInput = {
    copy(correlator = correlator)
  }
  def withCorrelator(correlator: String): DependencySnapshotInput = {
    copy(correlator = Option(correlator))
  }
  def withManifestPrefix(manifestPrefix: Option[String]): DependencySnapshotInput = {
    copy(manifestPrefix = manifestPrefix)
  }
  def withManifestPrefix(manifestPrefix: String): DependencySnapshotInput = {
    copy(manifestPrefix = Option(manifestPrefix))
  }
  def withRefOverride(refOverride: Option[String]): DependencySnapshotInput = {
    copy(refOverride = refOverride)
  }
  def withRefOverride(refOverride: String): DependencySnapshotInput = {
    copy(refOverride = Option(refOverride))
  }
}
object DependencySnapshotInput {
  
  def apply(onResolveFailure: Option[ch.epfl.scala.OnFailure], ignoredModules: Vector[String], ignoredConfigs: Vector[String], correlator: Option[String], manifestPrefix: Option[String], refOverride: Option[String]): DependencySnapshotInput = new DependencySnapshotInput(onResolveFailure, ignoredModules, ignoredConfigs, correlator, manifestPrefix, refOverride)
  def apply(onResolveFailure: ch.epfl.scala.OnFailure, ignoredModules: Vector[String], ignoredConfigs: Vector[String], correlator: String, manifestPrefix: String, refOverride: String): DependencySnapshotInput = new DependencySnapshotInput(Option(onResolveFailure), ignoredModules, ignoredConfigs, Option(correlator), Option(manifestPrefix), Option(refOverride))
}
