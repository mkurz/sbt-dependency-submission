/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala
import _root_.sjsonnew.{ Unbuilder, Builder, JsonFormat, deserializationError }
trait OnFailureFormats { self: sjsonnew.BasicJsonProtocol =>
implicit lazy val OnFailureFormat: JsonFormat[ch.epfl.scala.OnFailure] = new JsonFormat[ch.epfl.scala.OnFailure] {
  override def read[J](__jsOpt: Option[J], unbuilder: Unbuilder[J]): ch.epfl.scala.OnFailure = {
    __jsOpt match {
      case Some(__js) =>
      unbuilder.readString(__js) match {
        case "error" => ch.epfl.scala.OnFailure.error
        case "warning" => ch.epfl.scala.OnFailure.warning
      }
      case None =>
      deserializationError("Expected JsString but found None")
    }
  }
  override def write[J](obj: ch.epfl.scala.OnFailure, builder: Builder[J]): Unit = {
    val str = obj match {
      case ch.epfl.scala.OnFailure.error => "error"
      case ch.epfl.scala.OnFailure.warning => "warning"
    }
    builder.writeString(str)
  }
}
}
