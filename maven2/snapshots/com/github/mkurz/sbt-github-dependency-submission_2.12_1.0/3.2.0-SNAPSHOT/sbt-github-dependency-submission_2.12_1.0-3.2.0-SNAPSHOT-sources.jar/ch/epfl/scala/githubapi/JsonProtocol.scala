/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
trait JsonProtocol extends sjsonnew.BasicJsonProtocol
  with ch.epfl.scala.githubapi.JobFormats
  with ch.epfl.scala.githubapi.DetectorMetadataFormats
  with sbt.internal.util.codec.JValueFormats
  with ch.epfl.scala.githubapi.FileInfoFormats
  with ch.epfl.scala.githubapi.DependencyRelationshipFormats
  with ch.epfl.scala.githubapi.DependencyScopeFormats
  with ch.epfl.scala.githubapi.DependencyNodeFormats
  with ch.epfl.scala.githubapi.ManifestFormats
  with ch.epfl.scala.githubapi.DependencySnapshotFormats
  with ch.epfl.scala.githubapi.SnapshotResponseFormats
object JsonProtocol extends JsonProtocol