/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
final class FileInfo private (
  val source_location: Option[String]) extends Serializable {
  
  
  
  override def equals(o: Any): Boolean = this.eq(o.asInstanceOf[AnyRef]) || (o match {
    case x: FileInfo => (this.source_location == x.source_location)
    case _ => false
  })
  override def hashCode: Int = {
    37 * (37 * (17 + "ch.epfl.scala.githubapi.FileInfo".##) + source_location.##)
  }
  override def toString: String = {
    "FileInfo(" + source_location + ")"
  }
  private def copy(source_location: Option[String] = source_location): FileInfo = {
    new FileInfo(source_location)
  }
  def withSource_location(source_location: Option[String]): FileInfo = {
    copy(source_location = source_location)
  }
  def withSource_location(source_location: String): FileInfo = {
    copy(source_location = Option(source_location))
  }
}
object FileInfo {
  
  def apply(source_location: Option[String]): FileInfo = new FileInfo(source_location)
  def apply(source_location: String): FileInfo = new FileInfo(Option(source_location))
}
