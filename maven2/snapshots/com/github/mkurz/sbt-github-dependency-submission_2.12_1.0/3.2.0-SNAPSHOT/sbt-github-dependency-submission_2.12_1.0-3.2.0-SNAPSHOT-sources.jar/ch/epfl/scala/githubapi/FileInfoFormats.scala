/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
import _root_.sjsonnew.{ Unbuilder, Builder, JsonFormat, deserializationError }
trait FileInfoFormats { self: sjsonnew.BasicJsonProtocol =>
implicit lazy val FileInfoFormat: JsonFormat[ch.epfl.scala.githubapi.FileInfo] = new JsonFormat[ch.epfl.scala.githubapi.FileInfo] {
  override def read[J](__jsOpt: Option[J], unbuilder: Unbuilder[J]): ch.epfl.scala.githubapi.FileInfo = {
    __jsOpt match {
      case Some(__js) =>
      unbuilder.beginObject(__js)
      val source_location = unbuilder.readField[Option[String]]("source_location")
      unbuilder.endObject()
      ch.epfl.scala.githubapi.FileInfo(source_location)
      case None =>
      deserializationError("Expected JsObject but found None")
    }
  }
  override def write[J](obj: ch.epfl.scala.githubapi.FileInfo, builder: Builder[J]): Unit = {
    builder.beginObject()
    builder.addField("source_location", obj.source_location)
    builder.endObject()
  }
}
}
