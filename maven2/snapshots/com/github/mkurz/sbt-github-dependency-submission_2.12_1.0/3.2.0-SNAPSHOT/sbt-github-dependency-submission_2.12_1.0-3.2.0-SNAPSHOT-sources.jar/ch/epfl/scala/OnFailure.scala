/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala
sealed abstract class OnFailure extends Serializable
object OnFailure {
  
  
  case object error extends OnFailure
  case object warning extends OnFailure
}
