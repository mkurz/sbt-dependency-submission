/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
final class SnapshotResponse private (
  val id: Int,
  val created_at: Option[String]) extends Serializable {
  
  
  
  override def equals(o: Any): Boolean = this.eq(o.asInstanceOf[AnyRef]) || (o match {
    case x: SnapshotResponse => (this.id == x.id) && (this.created_at == x.created_at)
    case _ => false
  })
  override def hashCode: Int = {
    37 * (37 * (37 * (17 + "ch.epfl.scala.githubapi.SnapshotResponse".##) + id.##) + created_at.##)
  }
  override def toString: String = {
    "SnapshotResponse(" + id + ", " + created_at + ")"
  }
  private def copy(id: Int = id, created_at: Option[String] = created_at): SnapshotResponse = {
    new SnapshotResponse(id, created_at)
  }
  def withId(id: Int): SnapshotResponse = {
    copy(id = id)
  }
  def withCreated_at(created_at: Option[String]): SnapshotResponse = {
    copy(created_at = created_at)
  }
  def withCreated_at(created_at: String): SnapshotResponse = {
    copy(created_at = Option(created_at))
  }
}
object SnapshotResponse {
  
  def apply(id: Int, created_at: Option[String]): SnapshotResponse = new SnapshotResponse(id, created_at)
  def apply(id: Int, created_at: String): SnapshotResponse = new SnapshotResponse(id, Option(created_at))
}
