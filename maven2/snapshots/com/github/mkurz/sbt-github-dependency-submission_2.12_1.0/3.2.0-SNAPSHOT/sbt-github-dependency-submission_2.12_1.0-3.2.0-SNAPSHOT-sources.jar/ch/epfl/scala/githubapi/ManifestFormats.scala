/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
import _root_.sjsonnew.{ Unbuilder, Builder, JsonFormat, deserializationError }
trait ManifestFormats { self: ch.epfl.scala.githubapi.FileInfoFormats with sjsonnew.BasicJsonProtocol with sbt.internal.util.codec.JValueFormats with ch.epfl.scala.githubapi.DependencyNodeFormats =>
implicit lazy val ManifestFormat: JsonFormat[ch.epfl.scala.githubapi.Manifest] = new JsonFormat[ch.epfl.scala.githubapi.Manifest] {
  override def read[J](__jsOpt: Option[J], unbuilder: Unbuilder[J]): ch.epfl.scala.githubapi.Manifest = {
    __jsOpt match {
      case Some(__js) =>
      unbuilder.beginObject(__js)
      val name = unbuilder.readField[String]("name")
      val file = unbuilder.readField[Option[ch.epfl.scala.githubapi.FileInfo]]("file")
      val metadata = unbuilder.readField[Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue]]("metadata")
      val resolved = unbuilder.readField[Map[String, ch.epfl.scala.githubapi.DependencyNode]]("resolved")
      unbuilder.endObject()
      ch.epfl.scala.githubapi.Manifest(name, file, metadata, resolved)
      case None =>
      deserializationError("Expected JsObject but found None")
    }
  }
  override def write[J](obj: ch.epfl.scala.githubapi.Manifest, builder: Builder[J]): Unit = {
    builder.beginObject()
    builder.addField("name", obj.name)
    builder.addField("file", obj.file)
    builder.addField("metadata", obj.metadata)
    builder.addField("resolved", obj.resolved)
    builder.endObject()
  }
}
}
