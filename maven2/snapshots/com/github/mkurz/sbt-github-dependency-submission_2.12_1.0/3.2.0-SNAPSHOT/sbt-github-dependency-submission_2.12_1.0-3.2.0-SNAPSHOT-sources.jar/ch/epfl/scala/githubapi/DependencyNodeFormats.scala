/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
import _root_.sjsonnew.{ Unbuilder, Builder, JsonFormat, deserializationError }
trait DependencyNodeFormats { self: sbt.internal.util.codec.JValueFormats with ch.epfl.scala.githubapi.DependencyRelationshipFormats with sjsonnew.BasicJsonProtocol with ch.epfl.scala.githubapi.DependencyScopeFormats =>
implicit lazy val DependencyNodeFormat: JsonFormat[ch.epfl.scala.githubapi.DependencyNode] = new JsonFormat[ch.epfl.scala.githubapi.DependencyNode] {
  override def read[J](__jsOpt: Option[J], unbuilder: Unbuilder[J]): ch.epfl.scala.githubapi.DependencyNode = {
    __jsOpt match {
      case Some(__js) =>
      unbuilder.beginObject(__js)
      val package_url = unbuilder.readField[String]("package_url")
      val metadata = unbuilder.readField[Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue]]("metadata")
      val relationship = unbuilder.readField[Option[ch.epfl.scala.githubapi.DependencyRelationship]]("relationship")
      val scope = unbuilder.readField[Option[ch.epfl.scala.githubapi.DependencyScope]]("scope")
      val dependencies = unbuilder.readField[Vector[String]]("dependencies")
      unbuilder.endObject()
      ch.epfl.scala.githubapi.DependencyNode(package_url, metadata, relationship, scope, dependencies)
      case None =>
      deserializationError("Expected JsObject but found None")
    }
  }
  override def write[J](obj: ch.epfl.scala.githubapi.DependencyNode, builder: Builder[J]): Unit = {
    builder.beginObject()
    builder.addField("package_url", obj.package_url)
    builder.addField("metadata", obj.metadata)
    builder.addField("relationship", obj.relationship)
    builder.addField("scope", obj.scope)
    builder.addField("dependencies", obj.dependencies)
    builder.endObject()
  }
}
}
