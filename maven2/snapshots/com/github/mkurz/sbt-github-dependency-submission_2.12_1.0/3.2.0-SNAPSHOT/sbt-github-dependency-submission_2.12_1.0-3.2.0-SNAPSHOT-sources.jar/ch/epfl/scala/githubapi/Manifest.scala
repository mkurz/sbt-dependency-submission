/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
final class Manifest private (
  val name: String,
  val file: Option[ch.epfl.scala.githubapi.FileInfo],
  val metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue],
  val resolved: Map[String, ch.epfl.scala.githubapi.DependencyNode]) extends Serializable {
  
  
  
  override def equals(o: Any): Boolean = this.eq(o.asInstanceOf[AnyRef]) || (o match {
    case x: Manifest => (this.name == x.name) && (this.file == x.file) && (this.metadata == x.metadata) && (this.resolved == x.resolved)
    case _ => false
  })
  override def hashCode: Int = {
    37 * (37 * (37 * (37 * (37 * (17 + "ch.epfl.scala.githubapi.Manifest".##) + name.##) + file.##) + metadata.##) + resolved.##)
  }
  override def toString: String = {
    "Manifest(" + name + ", " + file + ", " + metadata + ", " + resolved + ")"
  }
  private def copy(name: String = name, file: Option[ch.epfl.scala.githubapi.FileInfo] = file, metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue] = metadata, resolved: Map[String, ch.epfl.scala.githubapi.DependencyNode] = resolved): Manifest = {
    new Manifest(name, file, metadata, resolved)
  }
  def withName(name: String): Manifest = {
    copy(name = name)
  }
  def withFile(file: Option[ch.epfl.scala.githubapi.FileInfo]): Manifest = {
    copy(file = file)
  }
  def withFile(file: ch.epfl.scala.githubapi.FileInfo): Manifest = {
    copy(file = Option(file))
  }
  def withMetadata(metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue]): Manifest = {
    copy(metadata = metadata)
  }
  def withResolved(resolved: Map[String, ch.epfl.scala.githubapi.DependencyNode]): Manifest = {
    copy(resolved = resolved)
  }
}
object Manifest {
  
  def apply(name: String, file: Option[ch.epfl.scala.githubapi.FileInfo], metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue], resolved: Map[String, ch.epfl.scala.githubapi.DependencyNode]): Manifest = new Manifest(name, file, metadata, resolved)
  def apply(name: String, file: ch.epfl.scala.githubapi.FileInfo, metadata: Map[String, sjsonnew.shaded.scalajson.ast.unsafe.JValue], resolved: Map[String, ch.epfl.scala.githubapi.DependencyNode]): Manifest = new Manifest(name, Option(file), metadata, resolved)
}
