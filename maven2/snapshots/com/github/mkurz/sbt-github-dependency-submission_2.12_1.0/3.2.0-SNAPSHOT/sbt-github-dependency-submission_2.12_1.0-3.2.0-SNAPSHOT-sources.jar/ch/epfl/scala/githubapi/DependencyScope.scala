/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala.githubapi
/**
 * A notation of whether the dependency is required for the primary
 * build artifact (runtime), or is only used for development.
 * Future versions of this specification may allow for more granular
 * scopes, like `runtime:server`, `runtime:shipped`,
 * `development:test`, `development:benchmark`.
 */
sealed abstract class DependencyScope extends Serializable
object DependencyScope {
  
  
  case object runtime extends DependencyScope
  case object development extends DependencyScope
}
