/**
 * This code is generated using [[https://www.scala-sbt.org/contraband]].
 */

// DO NOT EDIT MANUALLY
package ch.epfl.scala
import _root_.sjsonnew.{ Unbuilder, Builder, JsonFormat, deserializationError }
trait DependencySnapshotInputFormats { self: ch.epfl.scala.OnFailureFormats with sjsonnew.BasicJsonProtocol =>
implicit lazy val DependencySnapshotInputFormat: JsonFormat[ch.epfl.scala.DependencySnapshotInput] = new JsonFormat[ch.epfl.scala.DependencySnapshotInput] {
  override def read[J](__jsOpt: Option[J], unbuilder: Unbuilder[J]): ch.epfl.scala.DependencySnapshotInput = {
    __jsOpt match {
      case Some(__js) =>
      unbuilder.beginObject(__js)
      val onResolveFailure = unbuilder.readField[Option[ch.epfl.scala.OnFailure]]("onResolveFailure")
      val ignoredModules = unbuilder.readField[Vector[String]]("ignoredModules")
      val ignoredConfigs = unbuilder.readField[Vector[String]]("ignoredConfigs")
      val correlator = unbuilder.readField[Option[String]]("correlator")
      val shaOverride = unbuilder.readField[Option[String]]("shaOverride")
      val refOverride = unbuilder.readField[Option[String]]("refOverride")
      val manifestOverride = unbuilder.readField[Option[String]]("manifestOverride")
      unbuilder.endObject()
      ch.epfl.scala.DependencySnapshotInput(onResolveFailure, ignoredModules, ignoredConfigs, correlator, shaOverride, refOverride, manifestOverride)
      case None =>
      deserializationError("Expected JsObject but found None")
    }
  }
  override def write[J](obj: ch.epfl.scala.DependencySnapshotInput, builder: Builder[J]): Unit = {
    builder.beginObject()
    builder.addField("onResolveFailure", obj.onResolveFailure)
    builder.addField("ignoredModules", obj.ignoredModules)
    builder.addField("ignoredConfigs", obj.ignoredConfigs)
    builder.addField("correlator", obj.correlator)
    builder.addField("shaOverride", obj.shaOverride)
    builder.addField("refOverride", obj.refOverride)
    builder.addField("manifestOverride", obj.manifestOverride)
    builder.endObject()
  }
}
}
